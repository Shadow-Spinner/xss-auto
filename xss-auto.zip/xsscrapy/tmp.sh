#! /bin/bash
#! /bin/bash
a="a"
b="b$a"
c="c$b"
echo $c