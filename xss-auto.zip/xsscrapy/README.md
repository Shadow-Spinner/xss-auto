COMMANDS:

1. pip install -r requirments.txt
2. chmod 777 xss.sh
3. ./xss.sh <URL_LIST> -l <LOGIN_USER_NAME> -p <PASSWORD>
