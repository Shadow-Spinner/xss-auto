#!/bin/bash

# File containing URLs and number of parts
URL_FILE="discord.com.final.txt"
NUM_PARTS=5

# Timeout for each scan (in seconds) - 4 minutes
TIMEOUT=420

# Function to split URLs into equal parts
split_urls() {
    local url_file=$1
    local parts=$2

    # Check if the file exists
    if [[ ! -f "$url_file" ]]; then
        echo "Error: $url_file not found!"
        return 1
    fi

    # Check if the number of parts is a valid positive integer
    if ! [[ "$parts" =~ ^[0-9]+$ ]] || [[ "$parts" -le 0 ]]; then
        echo "Error: The number of parts must be a positive integer!"
        return 1
    fi

    # Count the total number of lines (URLs) in the file
    local total_lines=$(wc -l < "$url_file")

    # Calculate the number of lines per split
    local lines_per_split=$(( (total_lines + parts - 1) / parts )) # Round up to handle remainders

    # Create output files for each part
    split -l "$lines_per_split" -d --additional-suffix=.txt "$url_file" part_

    # Rename files for better readability
    for i in $(seq -f "%02g" 0 $((parts - 1))); do
        mv "part_$i.txt" "part$((10#$i + 1)).txt" 2>/dev/null
    done

    echo "URLs have been split into $parts parts:"
    for i in $(seq 1 $parts); do
        echo "  - part$i.txt"
    done

    return 0
}

# Function to perform scanning
scan_url() {
    local url=$1
    echo "Scanning: $url"
    timeout $TIMEOUT /usr/bin/python xsscrapy.py -u "$url"
    echo "Finished scanning: $url"
    echo "-----------------------------------"
}

# Split the URLs into the specified number of parts
split_urls "$URL_FILE" "$NUM_PARTS"

# List of files to process
URL_FILES=()
for i in $(seq 1 "$NUM_PARTS"); do
    URL_FILES+=("part$i.txt")
done

# Iterate over each URL list and open a GNOME terminal for it
for url_file in "${URL_FILES[@]}"; do
    if [[ ! -f "$url_file" ]]; then
        echo "Error: $url_file not found!"
        continue
    fi

    gnome-terminal -- bash -c "
    # Define the scan_url function
    scan_url() {
        local url=\$1
        echo \"Scanning: \$url\"
        timeout $TIMEOUT /usr/bin/python xsscrapy.py -u \"\$url\"
        echo \"Finished scanning: \$url\"
        echo \"-----------------------------------\"
    }

    # Read and process the URL file
    while IFS= read -r url; do
        scan_url \"\$url\"
    done < \"$url_file\"
    echo \"Scanning for $url_file completed!\"
    exec bash" &
done

# Wait for all terminals to finish
wait

# Cleanup temporary split files
for i in $(seq 1 "$NUM_PARTS"); do
    rm -f "part$i.txt"
done

echo "In process of scanning all URLs in $URL_FILE"
